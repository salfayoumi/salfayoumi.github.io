# Deploying this project

## Koyeb
Use the repository Dockerfile.

- Builder: Dockerfile
- Dockerfile location: `Dockerfile`
- Exposed port: `8080`
- Health check path: `/api/health`
- Do not set `RAPIDAPI_PROXY_SECRET` until the RapidAPI proxy secret has been created.
- Optional: `MAX_HISTORY_DAYS=366`

After deployment, verify:
- `/api/health`
- `/api/docs`
- `/api/prices/current?province=61&fuel_type=diesel`

## RapidAPI
The `rapidapi/` folder contains:
- `openapi-3.0.2.yaml`
- `listing.md`
