# Turkey Fuel Prices API

A read-only FastAPI service that normalizes official EPDK provincial gasoline, diesel, and automotive LPG price reports into developer-friendly JSON.

## Endpoints

- `GET /api/provinces`
- `GET /api/prices/current?province=61&fuel_type=diesel`
- `GET /api/prices/history?province=61&fuel_type=diesel&from_date=2026-09-01&to_date=2026-10-01`
- `GET /api/prices/compare?province=61&fuel_type=diesel`
- `GET /api/prices/change?province=61&fuel_type=diesel`
- `GET /api/health`
- Swagger: `/api/docs`

Accepted fuel aliases: `gasoline`/`benzin`, `diesel`/`motorin`, `lpg`/`otogaz`.
Province may be a Turkish name, unaccented spelling, or traffic code 1–81.

## Data source

The provider currently reads EPDK's official provincial petrol and LPG report forms and their XLS exports. Results are dated EPDK observations, not real-time station telemetry.

EPDK also publicly lists XML web services for provincial petroleum and LPG prices. Before production launch, test whether those endpoints are reachable from the chosen host; if reliable, migrating the provider to those official machine-to-machine services would reduce dependence on HTML form structure.

## Safety / production notes

- No price data is fabricated.
- Current requests are cached for 5 minutes; history for 30 minutes.
- A single history request is limited to `MAX_HISTORY_DAYS` (default: 366) to prevent one request from generating dozens of EPDK report downloads. Longer periods can be paginated.
- Set `RAPIDAPI_PROXY_SECRET` in production. When set, data endpoints require the `X-RapidAPI-Proxy-Secret` header added by RapidAPI. Docs and health endpoints remain public.
- Do not expose a production backend without the proxy-secret check or another access-control layer, otherwise callers can bypass RapidAPI billing/rate limits.

## Run locally

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8080
```

Open `http://localhost:8080/api/docs`.

## Environment

Copy `.env.example` values into your host's environment-variable UI. The application does not automatically load `.env`; hosts should inject environment variables.
