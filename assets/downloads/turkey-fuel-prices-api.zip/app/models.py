from __future__ import annotations

from datetime import date, datetime
from typing import Any, Generic, TypeVar

from pydantic import BaseModel, ConfigDict


T = TypeVar("T")


class ApiMeta(BaseModel):
    model_config = ConfigDict(extra="forbid")

    source: str
    retrieved_at: datetime
    currency: str | None = None
    unit: str | None = None


class ApiEnvelope(BaseModel, Generic[T]):
    data: T
    meta: ApiMeta


class ApiErrorDetail(BaseModel):
    code: str
    message: str
    details: dict[str, Any] | None = None


class ApiErrorResponse(BaseModel):
    error: ApiErrorDetail
    meta: ApiMeta | None = None


class ProvinceItem(BaseModel):
    code: int
    name: str


class ProvincesData(BaseModel):
    provinces: list[ProvinceItem]


class BrandPrice(BaseModel):
    brand: str
    price: float


class CurrentPriceData(BaseModel):
    province: str
    province_code: int
    fuel_type: str
    date: date
    minimum_price: float | None
    maximum_price: float | None
    average_price: float | None
    prices: list[BrandPrice]
    source: str
    last_updated: date


class PriceObservation(BaseModel):
    date: date
    minimum_price: float | None
    maximum_price: float | None
    average_price: float | None
    prices: list[BrandPrice]


class PriceHistoryData(BaseModel):
    province: str
    province_code: int
    fuel_type: str
    from_date: date
    to_date: date
    observations: list[PriceObservation]
    source: str
    last_updated: date | None


class PriceCompareData(BaseModel):
    province: str
    province_code: int
    fuel_type: str
    date: date | None
    prices: list[BrandPrice]
    minimum_price: float | None
    maximum_price: float | None
    average_price: float | None
    spread: float | None
    source: str
    last_updated: date | None


class PriceChangeData(BaseModel):
    province: str
    province_code: int
    fuel_type: str
    latest_date: date
    latest_price: float
    previous_day_price: float | None
    change_1d_percent: float | None
    change_7d_percent: float | None
    change_30d_percent: float | None
    source: str
    last_updated: date


class HealthData(BaseModel):
    status: str
    data_source: str
    version: str
