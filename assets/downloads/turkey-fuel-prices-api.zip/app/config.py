from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import os
import unicodedata


@dataclass(frozen=True)
class Province:
    code: int
    name: str


PROVINCES: tuple[Province, ...] = (
    Province(1, "Adana"),
    Province(2, "Adıyaman"),
    Province(3, "Afyonkarahisar"),
    Province(4, "Ağrı"),
    Province(5, "Amasya"),
    Province(6, "Ankara"),
    Province(7, "Antalya"),
    Province(8, "Artvin"),
    Province(9, "Aydın"),
    Province(10, "Balıkesir"),
    Province(11, "Bilecik"),
    Province(12, "Bingöl"),
    Province(13, "Bitlis"),
    Province(14, "Bolu"),
    Province(15, "Burdur"),
    Province(16, "Bursa"),
    Province(17, "Çanakkale"),
    Province(18, "Çankırı"),
    Province(19, "Çorum"),
    Province(20, "Denizli"),
    Province(21, "Diyarbakır"),
    Province(22, "Edirne"),
    Province(23, "Elazığ"),
    Province(24, "Erzincan"),
    Province(25, "Erzurum"),
    Province(26, "Eskişehir"),
    Province(27, "Gaziantep"),
    Province(28, "Giresun"),
    Province(29, "Gümüşhane"),
    Province(30, "Hakkâri"),
    Province(31, "Hatay"),
    Province(32, "Isparta"),
    Province(33, "Mersin"),
    Province(34, "İstanbul"),
    Province(35, "İzmir"),
    Province(36, "Kars"),
    Province(37, "Kastamonu"),
    Province(38, "Kayseri"),
    Province(39, "Kırklareli"),
    Province(40, "Kırşehir"),
    Province(41, "Kocaeli"),
    Province(42, "Konya"),
    Province(43, "Kütahya"),
    Province(44, "Malatya"),
    Province(45, "Manisa"),
    Province(46, "Kahramanmaraş"),
    Province(47, "Mardin"),
    Province(48, "Muğla"),
    Province(49, "Muş"),
    Province(50, "Nevşehir"),
    Province(51, "Niğde"),
    Province(52, "Ordu"),
    Province(53, "Rize"),
    Province(54, "Sakarya"),
    Province(55, "Samsun"),
    Province(56, "Siirt"),
    Province(57, "Sinop"),
    Province(58, "Sivas"),
    Province(59, "Tekirdağ"),
    Province(60, "Tokat"),
    Province(61, "Trabzon"),
    Province(62, "Tunceli"),
    Province(63, "Şanlıurfa"),
    Province(64, "Uşak"),
    Province(65, "Van"),
    Province(66, "Yozgat"),
    Province(67, "Zonguldak"),
    Province(68, "Aksaray"),
    Province(69, "Bayburt"),
    Province(70, "Karaman"),
    Province(71, "Kırıkkale"),
    Province(72, "Batman"),
    Province(73, "Şırnak"),
    Province(74, "Bartın"),
    Province(75, "Ardahan"),
    Province(76, "Iğdır"),
    Province(77, "Yalova"),
    Province(78, "Karabük"),
    Province(79, "Kilis"),
    Province(80, "Osmaniye"),
    Province(81, "Düzce"),
)


class FuelType(str, Enum):
    GASOLINE = "gasoline"
    DIESEL = "diesel"
    LPG = "lpg"


@dataclass(frozen=True)
class FuelDefinition:
    fuel_type: FuelType
    epdk_product: str
    report_kind: str
    unit: str = "TRY/litre"


FUEL_DEFINITIONS: dict[FuelType, FuelDefinition] = {
    FuelType.GASOLINE: FuelDefinition(
        FuelType.GASOLINE,
        "Kurşunsuz Benzin 95 Oktan",
        "petrol",
    ),
    FuelType.DIESEL: FuelDefinition(FuelType.DIESEL, "Motorin", "petrol"),
    FuelType.LPG: FuelDefinition(FuelType.LPG, "Otogaz", "lpg"),
}

_FUEL_ALIASES = {
    "gasoline": FuelType.GASOLINE,
    "benzin": FuelType.GASOLINE,
    "petrol": FuelType.GASOLINE,
    "diesel": FuelType.DIESEL,
    "motorin": FuelType.DIESEL,
    "lpg": FuelType.LPG,
    "otogaz": FuelType.LPG,
}

SOURCE_START_DATE = "2016-01-01"
SOURCE_MAX_WINDOW_DAYS = 93
CURRENT_LOOKBACK_DAYS = 14
CHANGE_LOOKBACK_DAYS = 60
MAX_HISTORY_DAYS = int(os.getenv("MAX_HISTORY_DAYS", "366"))


def normalize_text(value: str) -> str:
    """Normalize Turkish text for case- and accent-insensitive matching."""
    text = value.strip().casefold().replace("ı", "i")
    text = unicodedata.normalize("NFD", text)
    return " ".join(
        "".join(char for char in text if not unicodedata.combining(char)).split()
    )


def epdk_upper(value: str) -> str:
    """Match the Turkish uppercase province names used by EPDK's selectors."""
    return value.translate(str.maketrans({"i": "İ", "ı": "I"})).upper()


def resolve_province(value: str) -> Province:
    normalized = normalize_text(value)
    if normalized.isdecimal():
        code = int(normalized)
        if 1 <= code <= len(PROVINCES):
            return PROVINCES[code - 1]
        raise ValueError("Province code must be between 1 and 81.")

    for province in PROVINCES:
        if normalize_text(province.name) == normalized:
            return province
    raise ValueError("Province must be a Turkish province name or traffic code from 1 to 81.")


def resolve_fuel(value: str) -> FuelDefinition:
    normalized = normalize_text(value)
    fuel_type = _FUEL_ALIASES.get(normalized)
    if fuel_type is None:
        raise ValueError("fuel_type must be gasoline/benzin, diesel/motorin, or LPG/otogaz.")
    return FUEL_DEFINITIONS[fuel_type]
