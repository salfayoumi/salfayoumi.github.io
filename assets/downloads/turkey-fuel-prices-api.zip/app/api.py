from __future__ import annotations

from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Annotated
from zoneinfo import ZoneInfo

from fastapi import APIRouter, Query

from app.config import (
    CHANGE_LOOKBACK_DAYS,
    CURRENT_LOOKBACK_DAYS,
    PROVINCES,
    MAX_HISTORY_DAYS,
    SOURCE_START_DATE,
    FuelDefinition,
    Province,
    resolve_fuel,
    resolve_province,
)
from app.models import (
    ApiEnvelope,
    ApiMeta,
    ApiErrorResponse,
    BrandPrice,
    CurrentPriceData,
    PriceChangeData,
    PriceCompareData,
    PriceHistoryData,
    PriceObservation,
    ProvinceItem,
    ProvincesData,
)
from app.providers.epdk import EpdkProvider, EpdkUnavailable, OfficialPrice
from app.services.prices import (
    PriceService,
    change_target_dates,
    group_by_date,
    percent_change,
    sorted_prices,
    summarize_prices,
)


router = APIRouter()
_EPDK_PROVIDER = EpdkProvider()
_PRICE_SERVICE = PriceService(_EPDK_PROVIDER)
_CURRENT_CACHE_SECONDS = 300
_HISTORY_CACHE_SECONDS = 1800
_SOURCE_LABEL = "EPDK official provincial fuel-price reports"
_SOURCE_START = date.fromisoformat(SOURCE_START_DATE)
_TURKEY_TIME = ZoneInfo("Europe/Istanbul")


class ApiError(Exception):
    def __init__(self, status_code: int, code: str, message: str) -> None:
        self.status_code = status_code
        self.code = code
        self.message = message
        super().__init__(message)


def _now_utc() -> datetime:
    return datetime.now().astimezone().astimezone(ZoneInfo("UTC"))


def _today_in_turkey() -> date:
    return datetime.now(_TURKEY_TIME).date()


def _meta(retrieved_at: datetime, fuel: FuelDefinition | None = None) -> ApiMeta:
    return ApiMeta(
        source=_SOURCE_LABEL,
        retrieved_at=retrieved_at,
        currency="TRY" if fuel else None,
        unit=fuel.unit if fuel else None,
    )


def _resolve_inputs(province_value: str, fuel_value: str) -> tuple[Province, FuelDefinition]:
    try:
        province = resolve_province(province_value)
    except ValueError as error:
        raise ApiError(422, "INVALID_PROVINCE", str(error)) from error
    try:
        fuel = resolve_fuel(fuel_value)
    except ValueError as error:
        raise ApiError(422, "UNSUPPORTED_FUEL_TYPE", str(error)) from error
    return province, fuel


def _validate_period(start_date: date, end_date: date) -> None:
    today = _today_in_turkey()
    if start_date > end_date:
        raise ApiError(
            422,
            "INVALID_DATE_RANGE",
            "from_date must be on or before to_date.",
        )
    if end_date > today:
        raise ApiError(
            422,
            "INVALID_DATE_RANGE",
            "to_date cannot be in the future.",
        )
    if start_date < _SOURCE_START:
        raise ApiError(
            422,
            "DATE_OUT_OF_RANGE",
            f"EPDK provincial price reports are available from {_SOURCE_START.isoformat()}.",
        )
    requested_days = (end_date - start_date).days + 1
    if requested_days > MAX_HISTORY_DAYS:
        raise ApiError(
            422,
            "DATE_RANGE_TOO_LARGE",
            f"A single history request may span at most {MAX_HISTORY_DAYS} days. "
            "Paginate longer periods with multiple requests.",
        )


def _brand_prices(records: list[OfficialPrice]) -> list[BrandPrice]:
    return [
        BrandPrice(brand=brand, price=float(price))
        for brand, price in sorted_prices(records)
    ]


def _latest_records(records: list[OfficialPrice]) -> list[OfficialPrice]:
    if not records:
        return []
    latest_date = max(record.date for record in records)
    return [record for record in records if record.date == latest_date]


def _not_found_message(fuel: FuelDefinition, province: Province) -> str:
    return (
        f"EPDK has no {fuel.fuel_type.value} price observation for "
        f"{province.name} in the last {CURRENT_LOOKBACK_DAYS} days."
    )


@router.get(
    "/provinces",
    response_model=ApiEnvelope[ProvincesData],
    summary="List Turkish provinces",
    description=(
        "Returns all 81 Turkish provinces with their official traffic codes. "
        "Province names are accepted with Turkish or unaccented spelling."
    ),
)
async def list_provinces() -> ApiEnvelope[ProvincesData]:
    return ApiEnvelope(
        data=ProvincesData(
            provinces=[
                ProvinceItem(code=province.code, name=province.name)
                for province in PROVINCES
            ]
        ),
        meta=_meta(_now_utc()),
    )


@router.get(
    "/prices/current",
    response_model=ApiEnvelope[CurrentPriceData],
    responses={
        404: {"model": ApiErrorResponse, "description": "No recent official observation."},
        503: {"model": ApiErrorResponse, "description": "The EPDK source is unavailable."},
    },
    summary="Get the latest official provincial price",
    description=(
        "Returns distributor prices for the latest EPDK observation found in the "
        "last 14 days. This is a dated report, not live station telemetry."
    ),
)
async def current_price(
    province: Annotated[
        str,
        Query(description="Province name or traffic code from 1 to 81.", examples=["Trabzon", "61"]),
    ],
    fuel_type: Annotated[
        str,
        Query(description="gasoline/benzin, diesel/motorin, or LPG/otogaz.", examples=["diesel"]),
    ],
) -> ApiEnvelope[CurrentPriceData]:
    selected_province, fuel = _resolve_inputs(province, fuel_type)
    today = _today_in_turkey()
    start_date = max(_SOURCE_START, today - timedelta(days=CURRENT_LOOKBACK_DAYS))
    result = await _PRICE_SERVICE.get_prices(
        selected_province,
        fuel,
        start_date,
        today,
        ttl_seconds=_CURRENT_CACHE_SECONDS,
    )
    records = _latest_records(result.records)
    if not records:
        raise ApiError(404, "NO_PRICE_DATA", _not_found_message(fuel, selected_province))

    minimum, maximum, average, _ = summarize_prices(records)
    latest_date = records[0].date
    return ApiEnvelope(
        data=CurrentPriceData(
            province=selected_province.name,
            province_code=selected_province.code,
            fuel_type=fuel.fuel_type.value,
            date=latest_date,
            minimum_price=minimum,
            maximum_price=maximum,
            average_price=average,
            prices=_brand_prices(records),
            source="EPDK",
            last_updated=latest_date,
        ),
        meta=_meta(result.retrieved_at, fuel),
    )


@router.get(
    "/prices/history",
    response_model=ApiEnvelope[PriceHistoryData],
    responses={
        503: {"model": ApiErrorResponse, "description": "The EPDK source is unavailable."},
    },
    summary="Get official historical provincial prices",
    description=(
        "Returns dated distributor observations in the requested inclusive date "
        "range. EPDK accepts at most 93 days per report; longer ranges are split "
        "into compliant source requests."
    ),
)
async def price_history(
    province: Annotated[
        str,
        Query(description="Province name or traffic code from 1 to 81.", examples=["Trabzon"]),
    ],
    fuel_type: Annotated[
        str,
        Query(description="gasoline/benzin, diesel/motorin, or LPG/otogaz.", examples=["diesel"]),
    ],
    from_date: Annotated[date, Query(description="Inclusive start date (YYYY-MM-DD).")],
    to_date: Annotated[date, Query(description="Inclusive end date (YYYY-MM-DD).")],
) -> ApiEnvelope[PriceHistoryData]:
    selected_province, fuel = _resolve_inputs(province, fuel_type)
    _validate_period(from_date, to_date)
    result = await _PRICE_SERVICE.get_prices(
        selected_province,
        fuel,
        from_date,
        to_date,
        ttl_seconds=_HISTORY_CACHE_SECONDS,
    )

    observations: list[PriceObservation] = []
    by_date = group_by_date(result.records)
    for observation_date in sorted(by_date):
        records = by_date[observation_date]
        minimum, maximum, average, _ = summarize_prices(records)
        observations.append(
            PriceObservation(
                date=observation_date,
                minimum_price=minimum,
                maximum_price=maximum,
                average_price=average,
                prices=_brand_prices(records),
            )
        )

    return ApiEnvelope(
        data=PriceHistoryData(
            province=selected_province.name,
            province_code=selected_province.code,
            fuel_type=fuel.fuel_type.value,
            from_date=from_date,
            to_date=to_date,
            observations=observations,
            source="EPDK",
            last_updated=max(by_date) if by_date else None,
        ),
        meta=_meta(result.retrieved_at, fuel),
    )


@router.get(
    "/prices/compare",
    response_model=ApiEnvelope[PriceCompareData],
    responses={
        503: {"model": ApiErrorResponse, "description": "The EPDK source is unavailable."},
    },
    summary="Compare current distributor prices",
    description=(
        "Sorts EPDK's latest provincial distributor prices from low to high and "
        "calculates market statistics only from the returned observations."
    ),
)
async def compare_prices(
    province: Annotated[
        str,
        Query(description="Province name or traffic code from 1 to 81.", examples=["Trabzon"]),
    ],
    fuel_type: Annotated[
        str,
        Query(description="gasoline/benzin, diesel/motorin, or LPG/otogaz.", examples=["diesel"]),
    ],
) -> ApiEnvelope[PriceCompareData]:
    selected_province, fuel = _resolve_inputs(province, fuel_type)
    today = _today_in_turkey()
    start_date = max(_SOURCE_START, today - timedelta(days=CURRENT_LOOKBACK_DAYS))
    result = await _PRICE_SERVICE.get_prices(
        selected_province,
        fuel,
        start_date,
        today,
        ttl_seconds=_CURRENT_CACHE_SECONDS,
    )
    records = _latest_records(result.records)
    minimum, maximum, average, spread = summarize_prices(records)
    latest_date = max((record.date for record in records), default=None)
    return ApiEnvelope(
        data=PriceCompareData(
            province=selected_province.name,
            province_code=selected_province.code,
            fuel_type=fuel.fuel_type.value,
            date=latest_date,
            prices=_brand_prices(records),
            minimum_price=minimum,
            maximum_price=maximum,
            average_price=average,
            spread=spread,
            source="EPDK",
            last_updated=latest_date,
        ),
        meta=_meta(result.retrieved_at, fuel),
    )


@router.get(
    "/prices/change",
    response_model=ApiEnvelope[PriceChangeData],
    responses={
        404: {"model": ApiErrorResponse, "description": "No recent official observation."},
        503: {"model": ApiErrorResponse, "description": "The EPDK source is unavailable."},
    },
    summary="Calculate dated provincial price changes",
    description=(
        "Compares the latest official daily average with observations exactly 1, "
        "7, and 30 calendar days earlier. A percentage is null when the source "
        "has no observation on the comparison date."
    ),
)
async def price_change(
    province: Annotated[
        str,
        Query(description="Province name or traffic code from 1 to 81.", examples=["Trabzon"]),
    ],
    fuel_type: Annotated[
        str,
        Query(description="gasoline/benzin, diesel/motorin, or LPG/otogaz.", examples=["diesel"]),
    ],
) -> ApiEnvelope[PriceChangeData]:
    selected_province, fuel = _resolve_inputs(province, fuel_type)
    today = _today_in_turkey()
    start_date = max(_SOURCE_START, today - timedelta(days=CHANGE_LOOKBACK_DAYS))
    result = await _PRICE_SERVICE.get_prices(
        selected_province,
        fuel,
        start_date,
        today,
        ttl_seconds=_CURRENT_CACHE_SECONDS,
    )
    by_date = group_by_date(result.records)
    if not by_date:
        raise ApiError(404, "NO_PRICE_DATA", _not_found_message(fuel, selected_province))

    latest_date = max(by_date)
    latest_average = summarize_prices(by_date[latest_date])[2]
    if latest_average is None:
        raise ApiError(404, "NO_PRICE_DATA", _not_found_message(fuel, selected_province))
    target_dates = change_target_dates(latest_date)
    comparison_averages = {
        key: summarize_prices(by_date[target_date])[2] if target_date in by_date else None
        for key, target_date in target_dates.items()
    }
    return ApiEnvelope(
        data=PriceChangeData(
            province=selected_province.name,
            province_code=selected_province.code,
            fuel_type=fuel.fuel_type.value,
            latest_date=latest_date,
            latest_price=latest_average,
            previous_day_price=comparison_averages["1d"],
            change_1d_percent=percent_change(latest_average, comparison_averages["1d"]),
            change_7d_percent=percent_change(latest_average, comparison_averages["7d"]),
            change_30d_percent=percent_change(latest_average, comparison_averages["30d"]),
            source="EPDK",
            last_updated=latest_date,
        ),
        meta=_meta(result.retrieved_at, fuel),
    )
