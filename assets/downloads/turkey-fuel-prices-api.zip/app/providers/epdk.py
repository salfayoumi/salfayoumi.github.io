from __future__ import annotations

import asyncio
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation
from html.parser import HTMLParser
import io
import logging
import re
from typing import Any

import httpx
import xlrd

from app.config import (
    FUEL_DEFINITIONS,
    SOURCE_MAX_WINDOW_DAYS,
    FuelDefinition,
    Province,
    epdk_upper,
    normalize_text,
)


logger = logging.getLogger("turkey_fuel_prices.epdk")

PETROL_REPORT_URL = (
    "https://bildirim.epdk.gov.tr/bildirim-portal/faces/pages/tarife/petrol/"
    "illereGorePetrolAkaryakitFiyatSorgula.xhtml"
)
LPG_REPORT_URL = (
    "https://bildirim.epdk.gov.tr/bildirim-portal/faces/pages/tarife/lpg/"
    "illereGoreLPGFiyatSorgula.xhtml"
)

_MAX_RESPONSE_BYTES = 20 * 1024 * 1024
_SOURCE_CONCURRENCY = asyncio.Semaphore(3)
_USER_AGENT = (
    "TurkeyFuelPricesAPI/1.0 (+https://www.epdk.gov.tr/; "
    "official public price report client)"
)


class EpdkUnavailable(Exception):
    """The official EPDK report could not be queried or normalized safely."""


@dataclass(frozen=True)
class OfficialPrice:
    date: date
    province: str
    brand: str
    fuel_product: str
    price: Decimal


@dataclass(frozen=True)
class _Select:
    name: str
    value: str


@dataclass(frozen=True)
class _Button:
    name: str
    value: str
    label: str


@dataclass(frozen=True)
class _ReportForm:
    form_id: str
    hidden_fields: dict[str, str]
    date_fields: tuple[str, ...]
    selects: tuple[_Select, ...]
    buttons: tuple[_Button, ...]


class _ReportFormParser(HTMLParser):
    def __init__(self, target_form: str) -> None:
        super().__init__(convert_charrefs=True)
        self.target_form = target_form
        self.form_id: str | None = None
        self.in_target_form = False
        self.hidden_fields: dict[str, str] = {}
        self.date_fields: list[str] = []
        self.selects: list[_Select] = []
        self._current_select: dict[str, Any] | None = None
        self._current_option: dict[str, Any] | None = None
        self._buttons: list[_Button] = []
        self._current_button: dict[str, Any] | None = None

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        values = {name: value or "" for name, value in attrs}
        if tag == "form":
            self.in_target_form = values.get("id") == self.target_form
            if self.in_target_form:
                self.form_id = values["id"]
            return
        if not self.in_target_form:
            return

        if tag == "input":
            name = values.get("name", "")
            value = values.get("value", "")
            if not name:
                return
            if values.get("type") == "hidden":
                self.hidden_fields[name] = value
            elif values.get("type") == "text" and name.endswith("_input"):
                self.date_fields.append(name)
        elif tag == "select":
            name = values.get("name", "")
            if name:
                self._current_select = {
                    "name": name,
                    "first": None,
                    "selected": None,
                }
        elif tag == "option" and self._current_select is not None:
            self._current_option = {
                "value": values.get("value", ""),
                "selected": "selected" in values,
                "text": [],
            }
        elif tag == "button":
            name = values.get("name") or values.get("id", "")
            if name:
                self._current_button = {
                    "name": name,
                    "value": values.get("value") or name,
                    "label": [],
                }

    def handle_data(self, data: str) -> None:
        if self._current_option is not None:
            self._current_option["text"].append(data)
        if self._current_button is not None:
            self._current_button["label"].append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag == "option" and self._current_option is not None:
            option = self._current_option
            value = option["value"] or "".join(option["text"]).strip()
            if self._current_select is not None:
                if self._current_select["first"] is None:
                    self._current_select["first"] = value
                if option["selected"]:
                    self._current_select["selected"] = value
            self._current_option = None
        elif tag == "select" and self._current_select is not None:
            field = self._current_select
            self.selects.append(
                _Select(
                    name=field["name"],
                    value=field["selected"]
                    if field["selected"] is not None
                    else (field["first"] or ""),
                )
            )
            self._current_select = None
        elif tag == "button" and self._current_button is not None:
            button = self._current_button
            self._buttons.append(
                _Button(
                    name=button["name"],
                    value=button["value"],
                    label=" ".join("".join(button["label"]).split()),
                )
            )
            self._current_button = None
        elif tag == "form":
            self.in_target_form = False


def _parse_form(page: str, form_id: str) -> _ReportForm:
    parser = _ReportFormParser(form_id)
    parser.feed(page)
    if parser.form_id is None:
        raise EpdkUnavailable("EPDK's report form was not found.")
    if len(parser.date_fields) < 2 or len(parser.selects) < 3:
        raise EpdkUnavailable("EPDK's report form has changed unexpectedly.")
    if not parser.hidden_fields.get("javax.faces.ViewState"):
        raise EpdkUnavailable("EPDK's report session state was missing.")
    return _ReportForm(
        form_id=parser.form_id,
        hidden_fields=parser.hidden_fields,
        date_fields=tuple(parser.date_fields[:2]),
        selects=tuple(parser.selects[:3]),
        buttons=tuple(parser._buttons),
    )


def _button(form: _ReportForm, label: str) -> _Button:
    wanted = normalize_text(label)
    for button in form.buttons:
        if wanted in normalize_text(button.label):
            return button
    raise EpdkUnavailable(f"EPDK's {label} button was not found.")


def _form_data(
    form: _ReportForm,
    province: Province,
    fuel: FuelDefinition,
    start_date: date,
    end_date: date,
    button_label: str,
) -> dict[str, str]:
    button = _button(form, button_label)
    fields = dict(form.hidden_fields)
    fields[form.form_id] = form.form_id
    fields[form.date_fields[0]] = start_date.strftime("%d.%m.%Y")
    fields[form.date_fields[1]] = end_date.strftime("%d.%m.%Y")
    fields[form.selects[0].name] = (
        "Tümü" if fuel.report_kind == "petrol" else form.selects[0].value
    )
    fields[form.selects[1].name] = epdk_upper(province.name)
    fields[form.selects[2].name] = fuel.epdk_product
    fields[button.name] = button.value
    return fields


def _date_chunks(start_date: date, end_date: date) -> list[tuple[date, date]]:
    chunks: list[tuple[date, date]] = []
    cursor = start_date
    max_delta = timedelta(days=SOURCE_MAX_WINDOW_DAYS - 1)
    while cursor <= end_date:
        chunk_end = min(cursor + max_delta, end_date)
        chunks.append((cursor, chunk_end))
        cursor = chunk_end + timedelta(days=1)
    return chunks


def _cell_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()


def _cell_date(value: Any, datemode: int) -> date | None:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, (int, float)) and value > 0:
        try:
            return xlrd.xldate_as_datetime(value, datemode).date()
        except (ValueError, xlrd.XLDateError):
            return None
    raw = _cell_text(value)
    for date_format in ("%d.%m.%Y", "%d/%m/%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(raw, date_format).date()
        except ValueError:
            continue
    return None


def _cell_price(value: Any) -> Decimal | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, (int, float)):
        try:
            parsed = Decimal(str(value))
        except InvalidOperation:
            return None
        return parsed if parsed.is_finite() and parsed > 0 else None

    raw = _cell_text(value).replace(" ", "")
    if not raw:
        return None
    if "," in raw and "." in raw:
        if raw.rfind(",") > raw.rfind("."):
            raw = raw.replace(".", "").replace(",", ".")
        else:
            raw = raw.replace(",", "")
    elif "," in raw:
        raw = raw.replace(",", ".")
    try:
        parsed = Decimal(raw)
    except InvalidOperation:
        return None
    return parsed if parsed.is_finite() and parsed > 0 else None


def _parse_workbook(
    content: bytes,
    province: Province,
    fuel: FuelDefinition,
    start_date: date,
    end_date: date,
) -> list[OfficialPrice]:
    if len(content) > _MAX_RESPONSE_BYTES:
        raise EpdkUnavailable("EPDK's report was larger than the supported limit.")
    if not content.startswith(bytes.fromhex("D0CF11E0A1B11AE1")):
        raise EpdkUnavailable("EPDK did not return the expected Excel report.")
    try:
        workbook = xlrd.open_workbook(file_contents=content, logfile=io.StringIO())
        sheet = workbook.sheet_by_index(0)
    except (xlrd.XLRDError, IndexError, OSError) as error:
        raise EpdkUnavailable("EPDK's Excel report could not be read.") from error

    if sheet.nrows == 0:
        raise EpdkUnavailable("EPDK's Excel report was empty.")

    headers = {
        normalize_text(_cell_text(sheet.cell_value(0, column))): column
        for column in range(sheet.ncols)
    }
    required_groups = {
        "province": ("il", "il adi"),
        "brand": ("marka", "firma adi"),
        "fuel": ("yakit tipi",),
        "price": ("fiyat",),
        "date": ("tarih", "gecerlilik tarihi"),
    }
    columns: dict[str, int] = {}
    for field, alternatives in required_groups.items():
        match = next((headers[name] for name in alternatives if name in headers), None)
        if match is None:
            raise EpdkUnavailable("EPDK's Excel report columns have changed.")
        columns[field] = match

    target_province = normalize_text(province.name)
    target_fuel = normalize_text(fuel.epdk_product)
    records: list[OfficialPrice] = []
    for row_index in range(1, sheet.nrows):
        row = [sheet.cell_value(row_index, column) for column in range(sheet.ncols)]
        row_province = normalize_text(_cell_text(row[columns["province"]]))
        row_fuel = normalize_text(_cell_text(row[columns["fuel"]]))
        price_date = _cell_date(row[columns["date"]], workbook.datemode)
        price = _cell_price(row[columns["price"]])
        brand = _cell_text(row[columns["brand"]])
        product = _cell_text(row[columns["fuel"]])
        if (
            row_province != target_province
            or row_fuel != target_fuel
            or price_date is None
            or price is None
            or not brand
            or not start_date <= price_date <= end_date
        ):
            continue
        records.append(
            OfficialPrice(
                date=price_date,
                province=province.name,
                brand=brand,
                fuel_product=product,
                price=price,
            )
        )
    return records


async def _request_report(
    province: Province,
    fuel: FuelDefinition,
    start_date: date,
    end_date: date,
) -> list[OfficialPrice]:
    if fuel.report_kind == "lpg":
        url = LPG_REPORT_URL
        form_id = "lpgFiyatlariKriterleriForm"
    else:
        url = PETROL_REPORT_URL
        form_id = "akarYakitFiyatlariKriterleriForm"

    timeout = httpx.Timeout(35.0, connect=8.0)
    headers = {
        "User-Agent": _USER_AGENT,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "tr-TR,tr;q=0.9,en;q=0.7",
    }
    async with _SOURCE_CONCURRENCY:
        async with httpx.AsyncClient(
            timeout=timeout,
            follow_redirects=True,
            headers=headers,
        ) as client:
            try:
                page_response = await client.get(url)
                page_response.raise_for_status()
                first_form = _parse_form(page_response.text, form_id)
                search = await client.post(
                    url,
                    data=_form_data(
                        first_form,
                        province,
                        fuel,
                        start_date,
                        end_date,
                        "Sorgula",
                    ),
                    headers={"Referer": url},
                )
                search.raise_for_status()
                download_form = _parse_form(search.text, form_id)
                report = await client.post(
                    url,
                    data=_form_data(
                        download_form,
                        province,
                        fuel,
                        start_date,
                        end_date,
                        "Raporu İndir",
                    ),
                    headers={"Referer": url},
                )
                report.raise_for_status()
            except httpx.TimeoutException as error:
                raise EpdkUnavailable("The official EPDK report request timed out.") from error
            except httpx.HTTPStatusError as error:
                status_code = error.response.status_code
                raise EpdkUnavailable(
                    f"The official EPDK report returned HTTP {status_code}."
                ) from error
            except httpx.RequestError as error:
                raise EpdkUnavailable(
                    "The official EPDK report portal could not be reached."
                ) from error

    try:
        return _parse_workbook(
            report.content,
            province,
            fuel,
            start_date,
            end_date,
        )
    except EpdkUnavailable:
        logger.exception(
            "EPDK report could not be parsed",
            extra={"report_kind": fuel.report_kind},
        )
        raise


class EpdkProvider:
    """Reads the official EPDK provincial report and its XLS export."""

    async def get_prices(
        self,
        province: Province,
        fuel: FuelDefinition,
        start_date: date,
        end_date: date,
    ) -> list[OfficialPrice]:
        chunks = _date_chunks(start_date, end_date)
        results = await asyncio.gather(
            *(
                _request_report(province, fuel, chunk_start, chunk_end)
                for chunk_start, chunk_end in chunks
            )
        )
        records = [record for chunk in results for record in chunk]
        unique_records = {
            (record.date, record.brand, record.fuel_product, record.price): record
            for record in records
        }
        return sorted(
            unique_records.values(),
            key=lambda record: (record.date, record.brand.casefold(), record.price),
        )
