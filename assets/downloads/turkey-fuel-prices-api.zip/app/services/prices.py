from __future__ import annotations

import asyncio
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, ROUND_HALF_UP
import time

from app.config import FuelDefinition, Province
from app.providers.epdk import EpdkProvider, OfficialPrice


@dataclass(frozen=True)
class PriceResult:
    records: list[OfficialPrice]
    retrieved_at: datetime


@dataclass(frozen=True)
class _CacheEntry:
    expires_at: float
    result: PriceResult


class PriceService:
    def __init__(self, provider: EpdkProvider, max_cache_entries: int = 256) -> None:
        self._provider = provider
        self._max_cache_entries = max_cache_entries
        self._cache: dict[
            tuple[int, str, date, date], _CacheEntry
        ] = {}
        self._cache_lock = asyncio.Lock()

    async def get_prices(
        self,
        province: Province,
        fuel: FuelDefinition,
        start_date: date,
        end_date: date,
        ttl_seconds: int,
    ) -> PriceResult:
        key = (province.code, fuel.fuel_type.value, start_date, end_date)
        now = time.monotonic()
        async with self._cache_lock:
            entry = self._cache.get(key)
            if entry is not None and entry.expires_at > now:
                return entry.result
            if entry is not None:
                del self._cache[key]

        records = await self._provider.get_prices(
            province,
            fuel,
            start_date,
            end_date,
        )
        result = PriceResult(records=records, retrieved_at=datetime.now(timezone.utc))
        async with self._cache_lock:
            self._cache[key] = _CacheEntry(
                expires_at=time.monotonic() + ttl_seconds,
                result=result,
            )
            if len(self._cache) > self._max_cache_entries:
                oldest_key = next(iter(self._cache))
                del self._cache[oldest_key]
        return result


def sorted_prices(records: list[OfficialPrice]) -> list[tuple[str, Decimal]]:
    return sorted(
        ((record.brand, record.price) for record in records),
        key=lambda item: (item[1], item[0].casefold()),
    )


def summarize_prices(
    records: list[OfficialPrice],
) -> tuple[float | None, float | None, float | None, float | None]:
    values = [record.price for record in records]
    if not values:
        return None, None, None, None
    minimum = min(values)
    maximum = max(values)
    average = sum(values, Decimal(0)) / Decimal(len(values))
    spread = maximum - minimum if len(values) >= 2 else None
    return (
        _to_number(minimum),
        _to_number(maximum),
        _to_number(average),
        _to_number(spread) if spread is not None else None,
    )


def group_by_date(
    records: list[OfficialPrice],
) -> dict[date, list[OfficialPrice]]:
    grouped: dict[date, list[OfficialPrice]] = {}
    for record in records:
        grouped.setdefault(record.date, []).append(record)
    return grouped


def percent_change(current: float | None, previous: float | None) -> float | None:
    if current is None or previous is None or previous <= 0:
        return None
    value = (Decimal(str(current)) - Decimal(str(previous))) / Decimal(
        str(previous)
    ) * Decimal(100)
    return _to_number(value)


def _to_number(value: Decimal) -> float:
    rounded = value.quantize(Decimal("0.000001"), rounding=ROUND_HALF_UP)
    return float(rounded)


def change_target_dates(latest_date: date) -> dict[str, date]:
    return {
        "1d": latest_date - timedelta(days=1),
        "7d": latest_date - timedelta(days=7),
        "30d": latest_date - timedelta(days=30),
    }
