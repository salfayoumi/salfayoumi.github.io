from __future__ import annotations

from datetime import datetime, timezone
import hmac
import logging
import os
from time import perf_counter
from typing import Any

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.api import ApiError, router
from app.models import ApiErrorDetail, ApiErrorResponse, ApiMeta, HealthData
from app.providers.epdk import EpdkUnavailable


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)
logger = logging.getLogger("turkey_fuel_prices")

_RAPIDAPI_PROXY_SECRET = os.getenv("RAPIDAPI_PROXY_SECRET", "").strip()
_PUBLIC_PATHS = {
    "/health",
    "/api/health",
    "/api/healthz",
    "/api/docs",
    "/api/openapi.json",
}

app = FastAPI(
    title="Turkey Fuel Prices API",
    version="1.0.0",
    description=(
        "Read-only provincial gasoline, diesel, and automotive LPG prices from "
        "official EPDK reports. Prices are dated source observations, not live "
        "station telemetry. Historical requests are split to respect EPDK's "
        "93-day report limit. All prices are returned in TRY per litre."
    ),
    docs_url="/api/docs",
    openapi_url="/api/openapi.json",
    redoc_url=None,
    openapi_tags=[
        {"name": "Provinces", "description": "Official Turkish province list."},
        {"name": "Fuel prices", "description": "Current and historical EPDK observations."},
    ],
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET"],
    allow_headers=["*"],
)
app.include_router(router, prefix="/api", tags=["Fuel prices"])


def _health_data() -> HealthData:
    return HealthData(status="ok", data_source="EPDK", version="1.0.0")


@app.get("/health", response_model=HealthData, tags=["Health"])
@app.get("/api/health", response_model=HealthData, tags=["Health"])
@app.get(
    "/api/healthz",
    response_model=HealthData,
    include_in_schema=False,
)
async def health() -> HealthData:
    return _health_data()


@app.middleware("http")
async def log_request(request: Request, call_next: Any) -> Any:
    started = perf_counter()
    if (
        _RAPIDAPI_PROXY_SECRET
        and request.url.path.startswith("/api/")
        and request.url.path not in _PUBLIC_PATHS
    ):
        supplied = request.headers.get("X-RapidAPI-Proxy-Secret", "")
        if not hmac.compare_digest(supplied, _RAPIDAPI_PROXY_SECRET):
            return _error_response(403, "FORBIDDEN", "This endpoint is available through RapidAPI.")
    response = await call_next(request)
    elapsed_ms = (perf_counter() - started) * 1000
    logger.info(
        "%s %s %s %.1fms",
        request.method,
        request.url.path,
        response.status_code,
        elapsed_ms,
    )
    return response


def _error_response(
    status_code: int,
    code: str,
    message: str,
    details: dict[str, Any] | None = None,
) -> JSONResponse:
    error = ApiErrorResponse(
        error=ApiErrorDetail(code=code, message=message, details=details),
        meta=ApiMeta(
            source="EPDK",
            retrieved_at=datetime.now(timezone.utc),
        ),
    )
    return JSONResponse(
        status_code=status_code,
        content=error.model_dump(mode="json", exclude_none=True),
    )


@app.exception_handler(ApiError)
async def handle_api_error(_request: Request, error: ApiError) -> JSONResponse:
    return _error_response(error.status_code, error.code, error.message)


@app.exception_handler(EpdkUnavailable)
async def handle_epdk_error(_request: Request, error: EpdkUnavailable) -> JSONResponse:
    logger.warning("EPDK data source unavailable: %s", error)
    return _error_response(
        503,
        "EPDK_UNAVAILABLE",
        f"Official EPDK price data is temporarily unavailable: {error}",
    )


@app.exception_handler(RequestValidationError)
async def handle_validation_error(
    _request: Request,
    error: RequestValidationError,
) -> JSONResponse:
    issues = [
        {
            "field": ".".join(str(part) for part in item.get("loc", ())[1:]),
            "message": item.get("msg", "Invalid value."),
        }
        for item in error.errors()
    ]
    return _error_response(
        422,
        "VALIDATION_ERROR",
        "One or more request parameters are invalid.",
        {"issues": issues},
    )


@app.exception_handler(StarletteHTTPException)
async def handle_http_error(
    _request: Request,
    error: StarletteHTTPException,
) -> JSONResponse:
    code = "NOT_FOUND" if error.status_code == 404 else "HTTP_ERROR"
    message = str(error.detail) if isinstance(error.detail, str) else "The request could not be completed."
    return _error_response(error.status_code, code, message)


@app.exception_handler(Exception)
async def handle_unexpected_error(request: Request, error: Exception) -> JSONResponse:
    logger.exception("Unhandled request error at %s", request.url.path, exc_info=error)
    return _error_response(500, "INTERNAL_ERROR", "An unexpected server error occurred.")
