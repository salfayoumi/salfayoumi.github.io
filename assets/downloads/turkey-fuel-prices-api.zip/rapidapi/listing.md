# RapidAPI listing draft

## Name
Turkey Fuel Prices

## Short description
Current and historical provincial gasoline, diesel and LPG prices for Türkiye, normalized from official EPDK reports.

## Long description
Turkey Fuel Prices gives developers clean JSON access to official-source provincial fuel-price observations for Türkiye. Query by province name or traffic code and retrieve the latest available gasoline, diesel or LPG observations, historical series, distributor comparisons and 1/7/30-day change metrics.

The API reports dated EPDK observations and does not claim real-time station-level telemetry. Missing source data is returned transparently rather than estimated.

### Good for
- logistics and fleet dashboards
- e-commerce and delivery-cost tools
- transport and mobility apps
- economic/data dashboards
- research and historical analysis
- bots and automations

## Suggested launch plans
Start conservatively until real usage/EPDK load is observed.

- BASIC / Free: 50 requests per month, 10 requests/minute
- PRO: $5/month, 1,000 requests per month, 30 requests/minute
- ULTRA: $12/month, 5,000 requests per month, 60 requests/minute

Do not promise district/station-level or real-time coverage in the listing.

## Base URL
Set the RapidAPI Base URL to the HTTPS root of the deployed backend. The imported endpoint paths already include `/api/...`.

## Security
After RapidAPI creates the listing, copy the `X-RapidAPI-Proxy-Secret` value from the API's security/gateway settings into the hosting environment variable `RAPIDAPI_PROXY_SECRET`.
